# Drag'n Share
*Drag'n Share* is a very easy to use application with which you can share files
and directories across computers in a local network. This works on Windows, Mac
OSX and Linux and requires no internet or login credentials what so ever. And
above all, without any regard to privacy or security.

## Usage
When *Drag'n Share* is launched it will show it self in the system tray (the
icons near the clock). Clicking on the tray icon will show the *DropZone*.

To share a file you open the the *DropZone* and drop a file or directory in
this window. Other users in your network will see the dropped file and can drag
it back out the window. Share and receive file and directories in one drag.

## Authors
 * Koen "Kaji" Bollen <meneer@koenbollen.nl>
 * Nils "ThaNODnl" Dijk <me@thanod.nl>
